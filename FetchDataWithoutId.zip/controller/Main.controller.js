sap.ui.define(
	["infan/ar/fin/controller/BaseController"],
	function(BaseController) {
		return BaseController.extend("infan.ar.fin.controller.Main", {
			onInit: function() {
				// this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(),"emp");
				// this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(),"employees");
				
				sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel(),"emp");
				sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel(),"employees");

				// var oEmp = new sap.ui.model.json.JSONModel();
				// 	// oEmp.setData({
				// 	// 	"emp":{},
				// 	// 		"employees":{}
				// 	// });
				
				// sap.ui.getCore().setModel(oEmp, "emp");
				
			},
			empArray: [],
			onSubmit: function() {

				var name = sap.ui.getCore().getModel("emp").getProperty("/name");
				var age = sap.ui.getCore().getModel("emp").getProperty("/age");
				var dob = sap.ui.getCore().getModel("emp").getProperty("/dob");

				var jObject = {
					name: name,
					age: age,
					dob: dob
				};
				this.empArray.push(jObject);

				sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({
					empList: this.empArray
				}), "employees");
				sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel(), "emp");

			}

		});
	}
);